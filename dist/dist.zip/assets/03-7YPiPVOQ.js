const a="/avatars/03.jpg";export{a as _};
